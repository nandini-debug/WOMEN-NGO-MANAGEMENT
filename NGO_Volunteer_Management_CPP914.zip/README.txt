NGO VOLUNTEER MANAGEMENT — C++ PROJECT (CPP39)

Contents
- Source/: modular .h/.cpp files
- Data/: text files used for persistence
- Diagrams/: PlantUML use-case, class and sequence diagrams
- Executable/: place the compiled executable here
- Screenshots/: add screenshots of your own program run
- ProjectReport.pdf: create/attach your final report separately

Requirements implemented
- Classes and objects: Volunteer, Event, Skill, Assignment, NGO, FileManager, VolunteerSystem
- Encapsulation, default/parameterized constructors, destructors
- Runtime polymorphism through virtual Volunteer methods
- Dynamic memory (Volunteer pointers allocated with new and released with delete)
- Text-file persistence, validation and exception handling
- Modular .h/.cpp structure
- Add, display, search, update, delete, assign volunteer to event, report, save and load

Build (G++):
1. Open a terminal in the Source folder.
2. Compile:
   g++ -std=c++17 -Wall -Wextra main.cpp Volunteer.cpp Event.cpp Skill.cpp Assignment.cpp NGO.cpp FileManager.cpp VolunteerSystem.cpp -o ../Executable/Project.exe
3. Run from the Executable folder so ../Data paths work:
   Windows PowerShell: .\Project.exe
   Linux/macOS: ./Project.exe

Important:
- Run the executable with the working directory set to the Executable folder.
- Inputs containing "|" are rejected because "|" separates fields in the data files.
- Data files are plain text; back them up before editing.
- UML files are PlantUML source files. Render them with a PlantUML-compatible tool.
- Add real screenshots and a project report before final submission.
